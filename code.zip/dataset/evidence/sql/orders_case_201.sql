-- SQLite table export: orders_retained
INSERT INTO orders_retained VALUES ('ORD-99201', 'CUST-2026-1201', 149.50, 'USD', '2025-05-12', 'REDACTED', 'REDACTED');
