-- SQLite table export: orders_retained
INSERT INTO orders_retained VALUES ('ORD-99278', 'CUST-2026-1278', 149.50, 'USD', '2025-05-12', 'REDACTED', 'REDACTED');
